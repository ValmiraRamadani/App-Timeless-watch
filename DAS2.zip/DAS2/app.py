from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
import csv
import re
from datetime import datetime  # To capture the current date
import os  # Import your existing scraping functions

app = Flask(__name__, static_folder='images', static_url_path='/static')
app.secret_key = 'your_secret_key'

# File paths
USER_DATA_FILE = 'user_data.csv'
WATCH_DATA_FILE = 'watches.csv'

# Ensure the CSV file exists for users
if not os.path.exists(USER_DATA_FILE):
    with open(USER_DATA_FILE, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['First Name', 'Last Name', 'Date of Birth', 'Email', 'Username', 'Password', 'Date Joined'])

if not os.path.exists(WATCH_DATA_FILE):
    with open(WATCH_DATA_FILE, 'w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['Kontakt','Description'])

# Signup route
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        # Get form data
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        dob = request.form['dob']
        email = request.form['email']
        username = request.form['username']
        password = request.form['password']
        date_joined = datetime.now().strftime('%Y-%m-%d')  # Current date when the user signs up

        # Append user data to the CSV file
        with open(USER_DATA_FILE, 'a', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([first_name, last_name, dob, email, username, password, date_joined])

        return "Signup successful! You can now <a href='/login'>log in</a>."
    return render_template('signup.html')

@app.route('/addwatch', methods=['GET', 'POST'])
def addwatch():
    if request.method == 'POST':
        # Get form data
        kontakt = request.form['kontakt']
        description = request.form['description']

        # Append user data to the CSV file
        with open(WATCH_DATA_FILE, 'a', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow([kontakt,description])

        return "watch add successful! You can now <a href='/stockdata'>go to page</a>."
    return render_template('addwatch.html')
# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        with open(USER_DATA_FILE, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                if row[4] == username and row[5] == password:
                    session['username'] = username
                    flash('Login successful!', 'success')
                    return redirect(url_for('profile'))
        flash('Invalid username or password.', 'error')

    return render_template('login.html')

# Profile route
@app.route('/profile')
def profile():
    if 'username' not in session:
        flash('You need to log in first.', 'error')
        return redirect(url_for('login'))

    # Find the user details
    user = None
    with open(USER_DATA_FILE, 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[4] == session['username']:
                user = {
                    'name': row[0],
                    'lastname': row[1],
                    'dob': row[2],
                    'email': row[3],
                    'username': row[4],
                    'date_joined': row[6]  # Date joined is now part of the CSV
                }
                break
    return render_template('profile.html', user=user)
@app.route('/')
def home():
    return render_template('home_page.html')  # Ensure this template exists in your templates folder

@app.route('/stockdata')
@app.route('/stockdata', methods=['GET'])
def stockdata():
    # Initialize an empty list to hold the watch data
    watches = []

    # Open the CSV file and read its content
    with open(WATCH_DATA_FILE, 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        # Skip the header if it exists (optional)
        next(reader, None)  # Uncomment if your CSV file has a header row
        for row in reader:
            # Assuming 'Kontakt' is the first column and 'Description' is the second column
            kontakt, description = row
            watches.append({'kontakt': kontakt, 'description': description})

    # Pass the watches data to the template
    return render_template('stockdata.html', watches=watches)
@app.route('/homelogged')
def homelogged():
    return render_template('home_page_logged.html')  # Ensure this template exists in your templates folder
# Function to clean and split the 4th column while respecting commas inside quotes

@app.route('/logout')
def logout():
    return render_template('home_page.html')



import logging

logging.basicConfig(level=logging.DEBUG)  # Set the logging level to debug




if __name__ == '__main__':
    app.run(debug=True)
